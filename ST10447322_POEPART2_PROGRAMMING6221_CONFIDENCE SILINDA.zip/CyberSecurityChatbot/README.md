POE PART 1
#Overview:
CyberSecurity Chatbot is a C# console application designed to educate users about online safety. It provides interactive responses to questions about phishing, password security, safe browsing, and more. The chatbot enhances user experience with a voice greeting and an ASCII art logo.

#Features:
✅ Voice greeting to welcome users
✅ ASCII art banner for a visually engaging interface
✅ Interactive chatbot that answers cybersecurity-related questions
✅ Simulated typing effect for a more conversational experience

#Technologies Used:
C#
.NET Framework
Console Application

#Steps to Run the Project:
1.Clone the repository
2.Navigate to the project folder
3.Open the project in Visual Studio
4.Open CyberSecurityChatbot.sln
5.Run the program

#USAGE:
1.Enter your name when prompted.
2.Ask cybersecurity-related questions like:
"What is phishing?"
"What is your purpose?"
"What can i ask you about?"
3.Type "exit" to close the chatbot.

# Cybersecurity Awareness Chatbot - POE Part 2

## Overview

This is a console-based **Cybersecurity Chatbot** built using C# as part of a POE (Project of Evidence) for my Information Technology studies. The chatbot is designed to educate users on cybersecurity topics and promote safe online practices.

It offers a personalized, engaging experience through voice greetings, ASCII art, and a typing effect. The chatbot uses keyword detection, random fallback responses, and sentiment analysis to simulate meaningful conversations.

---

## Features

✅ **Voice Greeting** – Plays an audio file to welcome the user  
✅ **ASCII Art Banner** – Displays an engaging banner to introduce the chatbot  
✅ **Personalized User Greeting** – Asks for the user's name and responds accordingly  
✅ **Keyword Recognition** – Understands key cybersecurity terms and provides educational responses  
✅ **Dictionary-Based Responses** – Provides accurate answers to specific cybersecurity questions  
✅ **Random Fallback Responses** – Gives varied responses when the question is unknown  
✅ **Memory and Recall** – Remembers and recalls previously asked questions  
✅ **Sentiment Detection** – Responds differently to positive, neutral, or negative input  
✅ **Typing Effect** – Simulates realistic chatbot typing for better user interaction  
✅ **Exit Option** – User can type "exit" to close the chatbot

---

## How to Run the Project

1. **Clone or Download** the project files.
2. Open the solution in **Visual Studio**.
3. Make sure the `welcome_message.wav` file is in the correct directory:

