﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;

namespace CyberSecurityChatbot
{
    internal class Program
    {
        // List to remember previous questions asked by the user
        static List<string> previousQuestions = new List<string>();

        // Random object to choose random fallback responses
        static Random random = new Random();

        static void Main(string[] args)
        {
            // Play a welcome audio message
            PlayVoiceGreeting("welcome_message.wav");

            // Show ASCII art in the console
            DisplayAsciiArt();

            // Ask for user's name
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Enter your name: ");
            string userName = Console.ReadLine();

            // Use "User" if no name is entered
            if (string.IsNullOrWhiteSpace(userName))
            {
                userName = "User";
            }

            // Welcome the user
            Console.WriteLine($"\nHello {userName}, welcome to the Cybersecurity Awareness Bot!");
            Console.WriteLine("I'm here to help you stay safe online. Ask me anything about cybersecurity.");
            Console.ResetColor();

            // Main chat loop
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("\nYou: ");
                string userInput = Console.ReadLine()?.ToLower();
                Console.ResetColor();

                // Check for empty input
                if (string.IsNullOrWhiteSpace(userInput))
                {
                    ChatResponse("Please enter a valid question.");
                    continue;
                }

                // Check if the question was asked before
                if (previousQuestions.Contains(userInput))
                {
                    ChatResponse("You've already asked that! Want to ask something else?");
                    continue;
                }

                // Add new question to the memory
                previousQuestions.Add(userInput);

                // Detect user's feelings and respond
                DetectAndRespondToSentiment(userInput);

                // Simple keyword-based chatbot logic
                if (userInput.Contains("how are you?"))
                {
                    ChatResponse("I'm just a bot, but I'm here to help you stay secure online!");
                }
                else if (userInput.Contains("what is your purpose?"))
                {
                    ChatResponse("My purpose is to educate you about cybersecurity and how to stay safe online.");
                }
                else if (cyberSecurityTopics.ContainsKey(userInput))
                {
                    // Respond with a specific answer if input matches a known topic
                    ChatResponse(cyberSecurityTopics[userInput]);
                }
                else if (userInput.Contains("what can i ask you about?"))
                {
                    ChatResponse("You can ask me about: Phishing attacks, Password Safety, Safe Browsing, Online Scams, Data Privacy, Ransomware, VPNs, Firewalls.");
                }
                else if (userInput.Contains("exit"))
                {
                    // Exit the program
                    ChatResponse("Goodbye! Stay safe online!");
                    break;
                }
                else
                {
                    // If input is not understood, give a random fallback response
                    ChatResponse(GetRandomFallbackResponse());
                }
            }
        }

        // Function to play welcome audio
        static void PlayVoiceGreeting(string filePath)
        {
            try
            {
                SoundPlayer player = new SoundPlayer("C:\\Users\\RC_Student_lab\\source\\repos\\CyberSecurityChatbot\\bin\\Debug\\welcome_message.wav");
                player.PlaySync();
            }
            catch (Exception e)
            {
                Console.WriteLine("\n[Error] Unable to play the voice greeting.");
                Console.WriteLine(e.Message);
            }
        }

        // Function to display ASCII art
        static void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(@"
 ____ ____ ____ ____ ____ ____ ____ ____ ____ ____ 
||C |||Y |||B |||E |||R ||| ||| || | || | ||  |
||__|||__|||__|||__|||__|||__|||__|||__|||__|||__|
|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|
  ____ ____ ____ ____ ____ ____ ____ ____ ____ ____ 
 ||S |||E |||C |||U |||R |||I |||T |||Y |||! |||
 ||__|||__|||__|||__|||__|||__|||__|||__|||__|||__|
 |/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|
Protecting your digital world, one step at a time!
");
            Console.ResetColor();
        }

        // Function to print the bot’s response with typing effect
        static void ChatResponse(string response)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Bot: ");
            foreach (char c in response)
            {
                Console.Write(c);
                Thread.Sleep(20); // Add delay to simulate typing
            }
            Console.WriteLine();
            Console.ResetColor();
        }

        // Function to choose a random fallback response
        static string GetRandomFallbackResponse()
        {
            string[] fallbackResponses = new[]
            {
                "I didn't quite understand that. Could you rephrase?",
                "Hmm, I'm not sure about that. Try asking in another way.",
                "That's an interesting question. Can you be more specific?",
                "I'm still learning. Can you ask something related to cybersecurity?"
            };
            return fallbackResponses[random.Next(fallbackResponses.Length)];
        }

        // Function to detect emotions or mood from user input
        static void DetectAndRespondToSentiment(string input)
        {
            if (input.Contains("sad") || input.Contains("depressed") || input.Contains("unhappy"))
            {
                ChatResponse("I'm sorry you're feeling that way. Remember, you're not alone. Consider talking to someone you trust.");
            }
            else if (input.Contains("happy") || input.Contains("great") || input.Contains("good"))
            {
                ChatResponse("That's great to hear! Staying safe and happy is the goal.");
            }
            else if (input.Contains("angry") || input.Contains("frustrated"))
            {
                ChatResponse("I understand you're upset. Let's try to figure it out together.");
            }
        }

        // Dictionary containing known cybersecurity topics and their answers
        static readonly Dictionary<string, string> cyberSecurityTopics = new Dictionary<string, string>
        {
            { "what is phishing?", "Phishing is when hackers trick you into giving personal information through fake emails or websites. Don't click suspicious links!" },
            { "what is password safety?", "Use strong passwords with a mix of letters, numbers, and symbols. Enable two-factor authentication for extra security." },
            { "what is safe browsing?", "Always check website URLs, avoid public Wi-Fi for transactions, and keep your browser updated to stay secure online." },
            { "what is online scams?", "Online scams trick users into giving away money or information. Be cautious of too-good-to-be-true offers and verify sources." },
            { "what is data privacy?", "Protect your data by using encryption, avoiding oversharing on social media, and adjusting privacy settings on apps and websites." },
            { "what is ransomware?", "Ransomware is malicious software that locks your files and demands a ransom. Avoid suspicious downloads and back up your data regularly." },
            { "what is vpns?", "A VPN (Virtual Private Network) encrypts your internet connection, making your online activity more private and secure from hackers." },
            { "what are firewalls?", "Firewalls act as a barrier between your computer and the internet, blocking unauthorized access to protect your data." }
        };
    }
}


